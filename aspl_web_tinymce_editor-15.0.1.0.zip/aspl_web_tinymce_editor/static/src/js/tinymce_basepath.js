TINYMCE_BASEPATH='/aspl_web_tinymce_editor/static/lib/tinymce/'
